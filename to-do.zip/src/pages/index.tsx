import React from "react";
import Layout from "@/layout";

const HomePage: React.FC = () => {
  return (
    <Layout>
    <div>
      <h1>Home Page</h1>
      
    </div>
    </Layout>

  );
};

export default HomePage;

