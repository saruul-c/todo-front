import React from 'react';
import Dashboard from '@/components/dashboard'; // Import the Dashboard component

export default function Page() {
  return <Dashboard />; // Render the Dashboard component
}
